﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    public enum StatusWeight
    {
        ClassOne = 20,
        ClassTwo = 30,
        ClassThree = 35,
        ClassFour = 40 
    }
}
