﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class Random
    {
        //-------------------------------------------------------------------------------------
        // The Psudo Random Number Generator Method.
        // When Called Returns a Six Digit Random Number.
        // Generate a Six Digit Random Number for the Package Shipping Id.
        // Derived from a Program found on the Web.
        // Entry: Method is called with no value passed in.
        // Exit: When Called Returns a Six Digit Random Number.
        //-------------------------------------------------------------------------------------

        public static int GetPackageId()
        {
            int[] _digits = new int[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            System.Random random = new System.Random();

            int rand_digit = random.Next(0, 9);

            StringBuilder builder = new StringBuilder(6);

            string PackageId_AsString = "";
            int PackageId_AsNumber = 0;

            for (var i = 0; i < 6; i++)
            {
                builder.Append( _digits[rand_digit]);
            }

            PackageId_AsString = builder.ToString();
            PackageId_AsNumber = int.Parse(PackageId_AsString);

            return PackageId_AsNumber;
        }
    }
}
