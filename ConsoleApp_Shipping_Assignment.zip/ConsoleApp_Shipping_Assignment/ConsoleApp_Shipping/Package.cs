﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class Package
    {
        
        // Initalise the Class Properties.
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string PackageSender { get; set; }
        public string PackageReciever { get; set; }
        public int ShippingNumber { get; set; }
        public int Weight { get; set; }

        // Initalise the Class Constructor.
        public Package(string fname, string lname, string address, string city, string packageSender, string packageReciever, int shippingNumber, int weight)
        {
            FirstName = fname;
            LastName = lname;
            Address = address;
            City = city;
            PackageSender = packageSender;
            PackageReciever = packageReciever;
            ShippingNumber = shippingNumber;
            Weight = weight;
        }

        public Package() // Generate an Instance of the Class Constructor so we can call the Methods in this Class.
        {

        }

        //-----------------------------------------------------------------------------
        List<Package> Shipping = new List<Package>(); // Initalise a New Package List.
        //-----------------------------------------------------------------------------

        //****** The Class Methods begin here.******//

        // The First Method, this Prints out all the Package Details.
        //-------------------------------------------------------------
        public void PrintOutPackages()
        {
            
            foreach (var Package in Shipping)
            {
                Console.WriteLine("Package: {0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}", Package.FirstName, Package.LastName, Package.Address, Package.City, Package.PackageSender, Package.PackageReciever, Package.ShippingNumber, Package.Weight, Package);
            }

        }

        // The Second Method, Prints out a Count of all Packages in the Package List.
        //-----------------------------------------------------------------------------
        public void DisplayCount()
        {
            Console.WriteLine("The Count of All the Packages in the List is:  {0}", Shipping.Count);
            
        }

        // The Third Method, Lets the User view a Packages Details
        // Note: The Shipping Numbser is Required.
        public void ViewPackageDetails()
        {
            bool MenuFlag = true;
            int MenuCount = 1;

            while (MenuFlag == true)
            {
                
                Console.WriteLine("Please Type in the Shipping Number of the Package whose Details are to be Examined.");
                string input1 = Console.ReadLine();
                bool ifSuccess = int.TryParse(input1, out int number1);

                if (ifSuccess == true)
                {
                    MenuFlag = false;
                    MenuCount = MenuCount + 1;

                    // In this Method we use Linq to find the Package in the List.
                    var item = Shipping.FirstOrDefault(o => o.ShippingNumber == number1);
                    if (item == null)
                    {
                        MenuFlag = false;

                        Console.WriteLine("The Package Details are Empty for this Shipping Number: " + number1);
                        
                    }

                    Console.WriteLine("Package was found with this Shipping Number: " + number1);
                    Console.WriteLine("Package Details are: ");
                    Console.WriteLine(item);
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                }
                else if (MenuCount > 5)
                {
                    MenuFlag = false;

                    Console.WriteLine("Sorry, you have reached the Maximium Number of Trys.");
                    Console.WriteLine("The Program will now Exit.");
                    Console.WriteLine("Please press a Key. Thank You.");
                    Console.ReadKey();

                    Environment.Exit(0);
                }
                else
                {
                    MenuCount = MenuCount + 1;
                    MenuFlag = true;

                    Console.WriteLine("Sorry, you have not entered a valid Six Digit Integer Shipping Number.");
                    Console.WriteLine("Please Try again. You have Five Attempts.");
                    Console.WriteLine("This is Attempt Number: " + (MenuCount));
                }


            }
        }

        // The Fourth Method, Lets the User Delete a Package Details in a List.
        // Note: The Shipping Number is Required.
        public void DeletePackage()
        {
            bool MenuFlag1 = true;
            int MenuCount1 = 1;

            while (MenuFlag1 == true)
            {
                Console.WriteLine("Please Type in the Shipping Number of the Package whose Details are to be Deleted.");
                string input1 = Console.ReadLine();
                bool ifSuccess = int.TryParse(input1, out int number2);

                if (ifSuccess == true)
                {
                    MenuFlag1 = false;
                    MenuCount1 = MenuCount1 + 1;

                    // In this Method we use Linq to find the Package in the List.
                    var item1 = Shipping.FirstOrDefault(o => o.ShippingNumber == number2);

                    if (item1 == null)
                    {
                        MenuFlag1 = false;
                        MenuCount1 = MenuCount1 + 1;

                        Console.WriteLine("The Package Details are Empty for this Shipping Number: " + number2);

                    }
                    else if (item1 != null)
                    {
                        MenuFlag1 = false;
                        MenuCount1 = MenuCount1 + 1;

                        // Delete the Package Details that corrospond to the Shipping Number.
                        Shipping.Remove(item1);
                    }


                }
                else if (MenuCount1 > 5)
                {
                    MenuFlag1 = false;

                    Console.WriteLine("Sorry, you have reached the Maximium Number of Trys.");
                    Console.WriteLine("The Program will now Exit.");
                    Console.WriteLine("Please press a Key. Thank You.");
                    Console.ReadKey();

                    Environment.Exit(0);
                }
                else
                {
                    MenuCount1 = MenuCount1 + 1;
                    MenuFlag1 = true;

                    Console.WriteLine("Sorry, you have not entered a valid Six Digit Integer Shipping Number.");
                    Console.WriteLine("Please Try again. You have Five Attempts.");
                    Console.WriteLine("This is Attempt Number: " + (MenuCount1));
                }

            }

        }

        // The Fivth Method, Sorts the List by Sender's LastName.
        public void SortPackageDetails()
        {
            
            Shipping.Sort();

        }
        public void EnterPackageDetails()
        {
            bool menuFlag = true;
            bool menuFlag2 = true;
            int MenuCount = 1;
            int weight = 0;

            while (menuFlag == true)
            {
                int shippingNumber = Random.GetPackageId(); // Generate a Six Digit Random Shipping Number for the Package Id.

                Console.WriteLine("****** Package Details Entry Menu ******");
                Console.WriteLine("Please Enter the Package Details: ");

                Console.WriteLine("1: Please Enter the Sender's First Name and Press Return.");
                string fname = Console.ReadLine();

                Console.WriteLine("2: Please Enter the Sender's Last Name and Press Return.");
                string lname = Console.ReadLine();

                Console.WriteLine("3: Please Enter the Address and Press Return.");
                string address = Console.ReadLine();

                Console.WriteLine("4: Please Enter the City the Package was sent from and Press Return.");
                string city = Console.ReadLine();

                Console.WriteLine("5: Please Enter the Package Sender's Home City and Press Return.");
                string packageSender = Console.ReadLine();

                Console.WriteLine("6: Please Enter the Package Reciever's City and Press Return.");
                string packageReciever = Console.ReadLine();

                Console.WriteLine("Thank You for Entering the Details of the Package to be Shipped.");

                Console.WriteLine("Your Shipping Number is: " + shippingNumber); // Give the User the Package Shipping Number.

                Console.WriteLine("Please write it down and Keep it somewhere safe.");
                Console.WriteLine("As this is the only way we can track your Package."); // Please Do not lose the Shipping Number.!!

                //----------------------------------------------------------------------------------------------------------------------------------------------------------------------

                Shipping.Add(new Package(fname, lname, address, city, packageSender, packageReciever, shippingNumber, weight)); // This is where we add the Package Details to the List.

                TwoDayPackage pack = new TwoDayPackage(); // Create a new instance of TwoDayPackage to access its methods.

                pack.TwoDayOption(); // Dose the User want the Two Day Package Delivery Option.?

                OverNightPackage pack1 = new OverNightPackage(); // Create a new instance of OverNightPackage to access its methods.

                pack1.OverNightOption(); // Dose the User want the OverNight Delivery Option.?

                //------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                while (menuFlag2 == true)
                {
                    Console.WriteLine("Do you want to Enter Another Package's Details.? ");
                    Console.WriteLine("Please Type Y or N.");
                    string input = Console.ReadLine().ToLower();

                    if (input == "y")
                    {
                        menuFlag = true;

                        menuFlag2 = false; // Go around the Package Details section of the program again.

                        Console.WriteLine("You have chosen to Enter another Package's Details.");
                        Console.WriteLine("The Package Menu will appear again.");
                        Console.WriteLine("Please Press a Key.");
                        Console.ReadKey();
                    }
                    else if (input == "n")
                    {
                        menuFlag = false;

                        menuFlag2 = false; // Switch off the Flags and Exit this section of the Program.

                        Console.WriteLine("You have chosen not to Enter another Package's Details.");
                        Console.WriteLine("We have now completed entering Package's Details.");
                        Console.WriteLine("Please Press a Key.");
                        Console.ReadKey();
                    }

                    if (input != "y" && input != "n")
                    {

                        menuFlag = true;

                        menuFlag2 = true; // Scrambled input, Ask the User to try inputting a responce again. 

                        MenuCount = MenuCount + 1;

                        Console.WriteLine("You have not typed in a Correct Responce.");
                        Console.WriteLine("Please Type Y or N only. ");
                        Console.WriteLine("You have Five Attempts. This is Attempt number: " + MenuCount);

                    }
                    else if (MenuCount > 5)
                    {
                        menuFlag = false;

                        menuFlag2 = false; // Garabge input, Switch off the Flags and Exit the Program.

                        Console.WriteLine("Sorry, You have Exceeded the Specified Number of Attempts");
                        Console.WriteLine("This Program will now Exit. Please press a Key.");
                        Console.ReadLine();

                        Environment.Exit(0);

                    }

                }

            }

        }

    }
        

}


