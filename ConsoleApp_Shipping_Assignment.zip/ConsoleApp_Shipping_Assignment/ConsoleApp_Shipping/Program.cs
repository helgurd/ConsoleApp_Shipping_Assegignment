﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class Program
    {
        
        static void Main(string[] args)
        {

            Menu menu = new Menu(); // create an instance of the Menu Class to make the Properties Visable.

            int selection1 = menu.ShowMenu(); // Call the User Menu.

            menu.UsersChoice(selection1); // Process the Users Choice.

        }

    }   
    
}

