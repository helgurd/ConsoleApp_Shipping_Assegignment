﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class Menu
    {

        Package package = new Package(); // Create an Instance of non Static "Package"  Class.
             

        public int ShowMenu() // Method to Show the Menu.
        {
            int selection = 0;
            bool MenuFlag = true;
            int MenuCount = 1;

            while (MenuFlag == true)
            {
                Console.WriteLine("******** Shipping Menu *********");
                Console.WriteLine("Please Select an Option.");
                Console.WriteLine("1: Enter a New Package's Details.");
                Console.WriteLine("2: Sort the List of Packages.");
                Console.WriteLine("3: Select a Single Package and View it's Details.");
                Console.WriteLine("4: Delete a Single Package and it's Details.");
                Console.WriteLine("5: Display a Count of Packages in the List.");
                Console.WriteLine("6: Print Out All the Package Details in the Entire List.");
                Console.WriteLine("0: Exit the Program.");
                Console.WriteLine("******** End of Shipping Menu ***********");

                string input = Console.ReadLine();

                bool ifSuccess = int.TryParse(input, out selection);

                if (ifSuccess == true)
                {

                    MenuCount = MenuCount + 1;

                    if (selection == 0)
                    {
                        MenuFlag = false;

                        Console.WriteLine("You have selected the 0 (Exit) option.");
                        Console.WriteLine("Thank You, for using the Shipping Program.");
                        Console.WriteLine("The Program will now Exit.");
                        Console.WriteLine("Please Press a Key.");
                        Console.ReadKey();

                        Environment.Exit(0);
                    }

                    if (MenuCount > 5)
                    {
                        MenuFlag = false;

                        Console.WriteLine("Sorry, you have reached the Maximium Number of Trys.");
                        Console.WriteLine("The Program will now Exit.");
                        Console.WriteLine("Please press a Key. Thank You.");
                        Console.ReadKey();

                        Environment.Exit(0);
                    }

                    if (selection >= 1 && selection <= 6)
                    {
                        MenuFlag = false;

                        Console.WriteLine("Thank You, Your Selection is Valid.");
                    }

                }
                else
                {
                    MenuCount = MenuCount + 1;

                    Console.WriteLine("Sorry, You must Enter an Integer Value between 0 and 5.");
                    Console.WriteLine("Please Try again. You have Five Attempts.");
                    Console.WriteLine("This is Attempt Number: " + (MenuCount));
                }

                // End of While Loop.
            }

            return selection;
        }


        public void UsersChoice(int selection)
        {

            Console.WriteLine("You have selected Menu Option: " + (selection));
            Console.WriteLine("Please Press a Key.");
            Console.ReadKey();


            // Call the Methods Associated with Each Selection.
            switch (selection)
            {
                case 1:
                    Console.WriteLine("You have chosen to Add a Package's Details to the Shipping List.");
                    package.EnterPackageDetails();
                    Console.WriteLine("The Package's Details have now been added to the Shipping List.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                case 2:
                    Console.WriteLine("You have chosen to Sort the List of Packages.");
                    package.SortPackageDetails();
                    Console.WriteLine("The Package's Details have now been Sorted.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                case 3:
                    Console.WriteLine("You have chosen to Display a Package's Details.");
                    package.ViewPackageDetails();
                    Console.WriteLine("The Package's Details have now been Displayed.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                case 4:
                    Console.WriteLine("You have chosen to Delete a Package's Details from the List.");
                    package.DeletePackage();
                    Console.WriteLine("The Package's Details have now been Deleted from the List.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                case 5:
                    Console.WriteLine("You have chosen to Display a Count of All the Packages in the List.");
                    package.DisplayCount();
                    Console.WriteLine("A Count of All the Packages in the List has now been Displayed.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                case 6:
                    Console.WriteLine("You have chosen to Print Out all the Details of all the Packages in the List.");
                    package.PrintOutPackages();
                    Console.WriteLine("All the Packages in the List, have now Been Displayed.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();
                    break;

                default:
                    Console.WriteLine("An Error has Occured.");
                    Console.WriteLine("The Program will now Exit.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();

                    Environment.Exit(0);
                    break;
            }
        }


    }
}
