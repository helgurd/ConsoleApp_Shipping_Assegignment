﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class TwoDayPackage : Package
    {
        bool flag = false; // Two Day Shipping Flag. Initally set to Off.

        // Class Properties.
        public bool TwoDayFlag { get; set ; }
        public double TotalCost { get; set; }

        // Class Constructor.
        public TwoDayPackage(string fname, string lname, string address, string city, string packageSender, string packageReciever, int shippingNumber, int weight, double TotalCost, bool flag)
            : base(fname, lname, address, city, packageSender, packageReciever, shippingNumber, weight)
        {

            TwoDayFlag = flag;

        }

        public TwoDayPackage() // Create an Instance of the Class Constructors.
        {
        }

        // Class Method.
        public void TwoDayOption()
        {
            bool MenuFlag_1 = true;
            int MenuCount_1 = 1;
            double TotalCost = 0;

            int weight = PackageWeight.ShippingWeight(); // Get the weight of the Package.
            double cost = CostRange.GetCost(weight); // Calculate the Flat Rate Cost of Shipping the Package.

            while (MenuFlag_1 == true)
            {
                Console.WriteLine("****** Two Day Package Delivery Option Menu ******");
                Console.WriteLine("Do you want the Two Day Delivery, Package Option.?");
                Console.WriteLine("Type Y or N.");
                string input = Console.ReadLine().ToLower();

                if( input == "y")
                {
                    Console.WriteLine("You have selected the Two Day Delivery Option.");
                    Console.WriteLine("You will be charged an Extra 20 % for this service.");

                    TotalCost = cost + ((cost / 100) * 20);

                    MenuFlag_1 = false;

                    flag = true;

                    Console.WriteLine("The Total Cost for this Package's Delivery Service will be: " + TotalCost);

                }
                else if( input == "n")
                {
                    Console.WriteLine("You have chosen not to select the Two Day Delivery Service Option.");
                    Console.WriteLine("You will be Charged the Normal Rate for this Package Delivery Service.");

                    TotalCost = cost;

                    MenuFlag_1 = false;

                    flag = false; // set the Two Day Option Flag.

                    Console.WriteLine("The Total Cost for this Package's Delivery Service will be: " + TotalCost);
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();

                }


                if(input != "y" && input != "n")
                {
                    MenuFlag_1 = true;

                    MenuCount_1 = MenuCount_1 + 1;
                    Console.WriteLine("You have not inputted a Correct Responce.");
                    Console.WriteLine("Please Type Y or N only. ");
                    Console.WriteLine("You have Five Attempts. This is Attempt number: " + MenuCount_1);
                    
                }
                else if(MenuCount_1 > 5)
                {
                    MenuFlag_1 = false;

                    Console.WriteLine("Sorry, You have Exceeded the Specified Number of Attempts");
                    Console.WriteLine("This Program will now Exit. Please press a Key.");
                    Console.ReadLine();

                    Environment.Exit(0);

                }

            }

        }
    }
}
