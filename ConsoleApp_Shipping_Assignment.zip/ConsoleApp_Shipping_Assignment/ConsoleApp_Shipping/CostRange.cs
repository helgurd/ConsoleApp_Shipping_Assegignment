﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    public class CostRange
    {

        public static int GetCost(int weight)
        {

            int FlatRateCost = 0; // Initalise the Cost of the Package Delivery.
            
            if(weight >= 0 && weight <= 5)
            {
                FlatRateCost = (int)StatusWeight.ClassOne * weight; // Cast the Enums Definitions as an Int Type.
            }
            else if(weight > 5 && weight <= 10)
            {
                FlatRateCost = (int)StatusWeight.ClassTwo * weight;
            }
            else if(weight > 10 && weight <= 15)
            {
                FlatRateCost = (int)StatusWeight.ClassThree * weight;
            }
            else if(weight >= 16)
            {
                FlatRateCost = (int)StatusWeight.ClassFour * weight;
            }
            else
            {
                Console.WriteLine("Invalid Weight. Weight Input Equals: " + weight); // Default in case the weight input is less then zero.
                Console.WriteLine("The Program will now Exit. Please Press a Key.");
                Console.ReadLine(); 

                Environment.Exit(0);
            }

            return FlatRateCost;

        }
    }
}
