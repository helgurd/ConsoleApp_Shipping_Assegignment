﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Shipping
{
    class PackageWeight
    {
        public static int ShippingWeight()
        {
            //----------------------------------------------------------------------------------------------------------
            // Entry: Method is called with no value Passed in.
            // Exit: Method Returns Weight of Package in Grams as an Integer.
            //----------------------------------------------------------------------------------------------------------

            int weight = 0;
            bool MenuFlagWeight = true;
            int MenuCountWeight = 1;

            while (MenuFlagWeight == true)
            {
                Console.WriteLine("Please Enter the Package Weight in Grams , Rounded to the Nearest Gram.");
                Console.WriteLine("Note: Please Use the Weighing Scales Provided, to Weigh the Package.");

                string input = Console.ReadLine();

                bool ifSuccess = int.TryParse(input, out weight); // Try to Parse the input as an int and assign it to weight.

                if (ifSuccess == true)
                {
                    MenuFlagWeight = false;
                    Console.WriteLine("You have inputted a Package Weight of: " + weight + "Grams.");
                }
                else
                {
                    MenuCountWeight = MenuCountWeight + 1;

                    Console.WriteLine("You have not input a positive intger weight value.");
                    Console.WriteLine("Please try again.");
                    Console.WriteLine("You have Five Attempts.");
                    Console.WriteLine("This is attempt number: " + (MenuCountWeight));

                }

                if (MenuCountWeight > 5)
                {
                    MenuFlagWeight = false;

                    Console.WriteLine("Sorry, You have reached the Maximium number of Attempts.");
                    Console.WriteLine("This Program will now Exit.");
                    Console.WriteLine("Please Press a Key.");
                    Console.ReadKey();

                    System.Environment.Exit(0);
                }



            }

            return weight;
        }
    }
}
